const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CHUkF1bf.js","assets/dist-TLtlamx_.js"])))=>i.map(i=>d[i]);
import{t as e}from"./index-58FDQIu9.js";import{registerPlugin as t}from"./dist-TLtlamx_.js";var n=t(`Share`,{web:()=>e(()=>import(`./web-CHUkF1bf.js`).then(e=>new e.ShareWeb),__vite__mapDeps([0,1]))});export{n as Share};
//# sourceMappingURL=esm-Birycos8.js.map