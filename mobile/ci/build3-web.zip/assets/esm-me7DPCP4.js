const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CfpRHlG4.js","assets/dist-TLtlamx_.js"])))=>i.map(i=>d[i]);
import{t as e}from"./index-58FDQIu9.js";import{registerPlugin as t}from"./dist-TLtlamx_.js";var n=t(`App`,{web:()=>e(()=>import(`./web-CfpRHlG4.js`).then(e=>new e.AppWeb),__vite__mapDeps([0,1]))});export{n as App};
//# sourceMappingURL=esm-me7DPCP4.js.map