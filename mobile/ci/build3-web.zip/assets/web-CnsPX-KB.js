import{WebPlugin as e}from"./dist-TLtlamx_.js";var t=class extends e{async show(e){}async hide(e){}};export{t as SplashScreenWeb};
//# sourceMappingURL=web-CnsPX-KB.js.map